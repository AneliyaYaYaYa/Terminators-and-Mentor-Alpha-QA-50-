package com.company.oop.cosmetics.models;

import com.company.oop.cosmetics.models.products.Product;

import java.util.ArrayList;
import java.util.List;

public class Category {

    public static final int MIN_LENGTH_CATEGORY_NAME = 2;
    public static final int MAX_LENGTH_CATEGORY_NAME = 15;
    private String name;
    private List<Product> products;
    
    public Category(String name) {
        products = new ArrayList<>();
        setName(name);
        setProducts(products);
    }

    public String getName() {
        return name;
    }
    private void setName(String name) {
        if (name.length() < MIN_LENGTH_CATEGORY_NAME || name.length() > MAX_LENGTH_CATEGORY_NAME) {
            throw new IllegalArgumentException("Category name must be between 2 and 15 characters.");

        }
        if (name == null || name == "") {
            throw new IllegalArgumentException("Category name cannot be null.");
        }
        this.name = name;
    }


    public List<Product> getProducts() {
        return new ArrayList<>(products);
        //throw new UnsupportedOperationException("Not implemented yet.");
    }
    private void setProducts(List<Product> products) {
        if (products == null) {
            throw new IllegalArgumentException("Products cannot be null.");
        }
        this.products = products;
    }
    public void addProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }
        products.add(product);
       // throw new UnsupportedOperationException("Not implemented yet.");
    }
    
    public void removeProduct(Product product) {
        if (getProducts().contains(product)) {
            products.remove(product);
        }
        if (product == null) {
            throw new IllegalArgumentException("Product cannot be null.");
        }
    }
    
    public String print() {
        //String message = String.format("#Category: {%s}%n #Name Brand%n#Price: {%d}%n#Gender: {genderType}%n===%n", name, products);
        throw new UnsupportedOperationException("Not implemented yet.");
    }
    
}
