package com.company.oop.cosmetics.models.common;

public enum GenderType {
    WOMAN,
    UNISEX,
    MEN
}
