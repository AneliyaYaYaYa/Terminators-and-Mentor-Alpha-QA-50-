package com.company.oop.cosmetics.commands.enums;

public enum CommandType {
    CREATECATEGORY,
    ADDTOCATEGORY,
    SHOWCATEGORY,
    CREATEPRODUCT,
    ADDTOSHOPPINGCART,
    REMOVEFROMSHOPPINGCART,
    REMOVEFROMCATEGORY,
    TOTALPRICE;
}
