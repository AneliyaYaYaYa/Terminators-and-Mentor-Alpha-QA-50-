package com.company.oop.cosmetics.models.products;

public enum GenderType {
    Men,
    Women,
    Unisex
}
