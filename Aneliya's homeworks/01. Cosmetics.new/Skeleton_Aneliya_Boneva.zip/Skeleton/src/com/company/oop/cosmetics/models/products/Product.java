package com.company.oop.cosmetics.models.products;

import com.company.oop.cosmetics.models.common.GenderType;

public class Product {

    public static final int MIN_LENGTH_PRODUCT_NAME = 3;
    public static final int MAX_LENGTH_PRODUCT_NAME = 10;
    public static final int MIN_LENGTH_BRAND_NAME = 2;
    public static final int MAX_LENGTH_BRAND_NAME = 10;
    private double price;
    private String name;
    private String brand;
    private GenderType gender;
    
    public Product(String name, String brand, double price, GenderType gender) {
        setName(name);
        setBrand(brand);
        setPrice(price);
        this.gender = gender; // how to use enum in setter/getter/constructor
    }

    public double getPrice() {
        return price;
    }
    private void setPrice(double price) {
        if (price > 0) {
        this.price = price;
        } else {
            throw new IllegalArgumentException("Price cannot be below 0.");
        }
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        if (name.length() < MIN_LENGTH_PRODUCT_NAME || name.length() > MAX_LENGTH_PRODUCT_NAME) {
            throw new IllegalArgumentException("Product name must be between 3 and 10 characters.");
        }
        if (name == null || name == " ") {
            throw new IllegalArgumentException("Product name cannot be null.");
        }
        this.name = name;
    }

    public String getBrand() {
        return brand;
    }

    private void setBrand(String brand) {
        if (brand.length() > MIN_LENGTH_BRAND_NAME && brand.length() < MAX_LENGTH_BRAND_NAME) {
            this.brand = brand;
        } else {
            throw new IllegalArgumentException("Brand name must be between 2 and 10 characters.");
        }
    }

    public String print() {
        String message = String.format(" #[%s] [%s]%n#Price: [%.2f]%n#Gender: [%s]%n===%n", name, brand, price, gender);
        return message;
        // Format:
        //" #[Name] [Brand]
        // #Price: [Price]
        // #Gender: [Gender]
        // ==="
    }
    
}
