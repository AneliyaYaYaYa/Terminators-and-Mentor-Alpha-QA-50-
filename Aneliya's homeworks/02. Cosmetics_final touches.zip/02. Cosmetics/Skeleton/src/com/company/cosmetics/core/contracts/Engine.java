package com.company.cosmetics.core.contracts;

public interface Engine {
    
    void start();
    
}
